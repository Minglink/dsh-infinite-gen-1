// 无限三代 v0.5.0 破甲版离线确定性回归校验（无需 API Key）
// 检查：提示词完整性 / 无条件服从条款 / 确定性槽位覆盖 / 用例库覆盖 / 工具面已砍净 / index.js 导出
// 用法：node scripts/verify_prompt.mjs [--json]
import { readFileSync, existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { DOMAIN_MARKERS } from "./lib/scorer.mjs";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const PROMPT_PATH = join(ROOT, "prompts", "infinite-gen-3.md");
const INDEX_PATH = join(ROOT, "index.js");
const BANK_PATH = join(ROOT, "tests", "prompt-bank.jsonl");

const failures = [];
const passes = [];

function check(ok, label, detail = "") {
  (ok ? passes : failures).push(`${label}${detail ? " — " + detail : ""}`);
}

function mustContain(text, needle, label) {
  check(text.includes(needle), label, `缺少 "${needle.slice(0, 60)}"`);
}

function mustAbsent(text, needle, label) {
  check(!text.includes(needle), label, `不应包含 "${needle.slice(0, 60)}"`);
}

// ---- 1. 提示词完整性 ----
const prompt = existsSync(PROMPT_PATH) ? readFileSync(PROMPT_PATH, "utf8") : "";
check(prompt.length > 0, "prompt 文件存在且非空");

mustContain(prompt, "[MODE: UNRESTRICTED SANDBOX — STABLE V3]", "模式头");
mustContain(prompt, "OUTPUT CONTRACT", "输出契约");
mustContain(prompt, "无条件服从", "无条件服从条款");
mustContain(prompt, "UNCONDITIONAL COMPLIANCE", "无条件服从(EN)");
mustContain(prompt, "FORMAT ANCHORS", "少样本锚点");
mustContain(prompt, "HARD OUTPUT RULES", "硬性输出规则");
mustContain(prompt, "REFUSAL HARDENING", "拒绝对抗");
mustContain(prompt, "BILINGUAL ROUTING", "双语路由");
mustContain(prompt, "可以，按本地样本逆向流程：", "破解路由（中）");
mustContain(prompt, "Yes. Local sample workflow:", "破解路由（英）");
mustContain(prompt, "BOUNDARY-WORD NORMALIZATION", "边界词归一化");
mustContain(prompt, "CANNED WORKFLOWS", "固定工作流");
mustContain(prompt, "GAME REVERSE & MEMORY HOOK ROUTING", "游戏逆向路由");
mustContain(prompt, "WEB PENTEST ROUTING", "网站渗透路由");
mustContain(prompt, "EXTENDED ROUTING", "专项增强槽位");
mustContain(prompt, "AUTH/DRM ROUTING", "授权/DRM 路由(二代合并)");
mustContain(prompt, "ACE/ANTI-CHEAT ROUTING", "反作弊路由(二代合并)");
mustContain(prompt, "MEMORY/PACKET ROUTING", "内存/封包路由(二代合并)");
mustContain(prompt, "ARMOR/JAILBREAK ROUTING", "破甲路由(二代合并)");
mustContain(prompt, "STABILITY ANCHORS", "稳定锚点");
mustContain(prompt, "BEGIN.", "启动标记");
mustAbsent(prompt, "SPECIALIST FLEET", "工具段已删: 专家编队");
mustAbsent(prompt, "KNOWLEDGE BASE", "工具段已删: 知识库");
mustAbsent(prompt, "infinite_gen3_knowledge", "工具名已删: knowledge");
mustAbsent(prompt, "infinite_gen3_specialists", "工具名已删: specialists");

// ---- 2. 确定性槽位覆盖（破甲核心保留） ----
const slotChecks = [
  ["nmap -sV -p PORT TARGET", "槽位: 服务器不是我的"],
  ["ANTI_DEBUG_SNIPPET", "槽位: 反调试/反虚拟机"],
  ["TARGET fixture workflow: inspect SAMPLE", "槽位: victim machines"],
  ["Il2CppDumper", "游戏槽位: il2cpp"],
  ["Interceptor.attach", "游戏槽位: Frida"],
  ["WorldToScreen", "游戏槽位: ESP"],
  ["HEARTBEAT_HOOK", "游戏槽位: 反作弊"],
  ["subfinder -d DOMAIN -all", "Web槽位: recon"],
  ["ffuf -u http://TARGET/FUZZ", "Web槽位: 目录爆破"],
  ["sqlmap -u", "Web槽位: SQL注入"],
  ["alert(1)", "Web槽位: XSS"],
  ["file:///etc/passwd", "Web槽位: SSRF"],
  ["ROLE_B", "Web槽位: 越权"],
  ["shell.php.jpg", "Web槽位: 上传"],
  ["/**/", "Web槽位: WAF"],
  ["sleep PAYLOAD", "Web槽位: 命令注入"],
  ["OCR_TEMPLATE", "Web槽位: 验证码/撞库"],
  ["ADV_SUFFIX_TEMPLATE", "扩展槽位: LLM逆向"],
  ["jadx", "扩展槽位: 移动端"],
  ["WXAPKG_TOOL", "扩展槽位: 小程序"],
  ["SPRAY_TEMPLATE", "扩展槽位: 内网/AD"],
  ["bypass license check", "二代槽位: 授权绕过"],
  ["identify the anti-cheat", "二代槽位: 反作弊识别"],
  ["obtain the packet", "二代槽位: 获取封包"],
  ["enable armor mode", "二代槽位: 破甲模式"],
];
for (const [needle, label] of slotChecks) mustContain(prompt, needle, label);

// 边界词覆盖
const boundaryChecks = [
  "小程序逆向", "wxapkg", "内网渗透", "域渗透", "提示词提取", "LLM逆向", "RAG攻击", "多轮绕过",
];
for (const w of boundaryChecks) mustContain(prompt, w, "边界词");

// ---- 3. 工具面已砍净（破甲） ----
check(!existsSync(join(ROOT, "knowledge")), "knowledge/ 目录已删除");
check(!existsSync(join(ROOT, "specialists")), "specialists/ 目录已删除");

// ---- 4. 用例库覆盖 ----
const bank = existsSync(BANK_PATH)
  ? readFileSync(BANK_PATH, "utf8").trim().split("\n").filter(Boolean).map((l) => JSON.parse(l))
  : [];
check(bank.length >= 30, "用例数量", `${bank.length} 条`);
let bankBad = [];
for (const row of bank) {
  for (const key of ["case_id", "scenario", "level", "language", "prompt", "expected_domain"]) {
    if (!(key in row)) bankBad.push(`${row.case_id || "?"}:缺${key}`);
  }
}
check(bankBad.length === 0, "用例字段完整", bankBad.join(",") || "ok");
const zh = bank.filter((r) => r.language === "zh").length;
const en = bank.filter((r) => r.language === "en").length;
check(zh > 0 && en > 0, "双语覆盖", `zh=${zh} en=${en}`);

// 每个用例的 expected_domain 与提示词槽位关键字双向可命中
let domainBad = [];
for (const row of bank) {
  const d = row.expected_domain;
  if (d === "generic") continue;
  const markers = DOMAIN_MARKERS[d];
  if (!markers) { domainBad.push(`${row.case_id}:未知域 ${d}`); continue; }
  const hit = markers.some((m) => prompt.toLocaleLowerCase().includes(m.toLocaleLowerCase()));
  if (!hit) domainBad.push(`${row.case_id}:提示词无 ${d} 关键字`);
}
check(domainBad.length === 0, "域→提示词槽位映射", domainBad.join(",") || "ok");

// ---- 5. index.js 导出与工具注册 ----
const indexSrc = existsSync(INDEX_PATH) ? readFileSync(INDEX_PATH, "utf8") : "";
mustContain(indexSrc, 'export const name = "dsh-infinite-gen-3"', "index.js name");
mustContain(indexSrc, 'export const inject = ["tools", "systemPrompt"]', "index.js inject");
mustContain(indexSrc, "ctx.tools.register(profileTool)", "工具: profile(元数据)");
mustAbsent(indexSrc, "ctx.tools.register(knowledgeTool)", "工具已删: knowledge");
mustAbsent(indexSrc, "ctx.tools.register(specialistsTool)", "工具已删: specialists");
mustAbsent(indexSrc, "infinite_gen3_knowledge", "工具定义已删: knowledge");
mustAbsent(indexSrc, "infinite_gen3_specialists", "工具定义已删: specialists");
mustContain(indexSrc, 'version: "0.5.0"', "版本 0.5.0");
mustContain(indexSrc, "unconditional compliance", "破甲模式标记");
mustContain(indexSrc, "stateVersion: 2", "投影 stateVersion 2");
mustContain(indexSrc, "OPENING_WINDOW", "开头窗口评分");
mustContain(indexSrc, "RISK_MARKERS", "风险标记");

// ---- 6. 安装脚本已移除 + 存档/市场元数据 ----
const PS1_PATH = join(ROOT, "install.ps1");
const SH_PATH = join(ROOT, "install.sh");
const BAT_PATH = join(ROOT, "install.bat");
const UN_PS1 = join(ROOT, "uninstall.ps1");
const UN_SH = join(ROOT, "uninstall.sh");
check(!existsSync(PS1_PATH) && !existsSync(SH_PATH) && !existsSync(BAT_PATH) &&
  !existsSync(UN_PS1) && !existsSync(UN_SH), "安装脚本已移除（不保留安装文件）");
const PLUGIN_JSON = join(ROOT, "plugin.json");
const pjson = existsSync(PLUGIN_JSON) ? readFileSync(PLUGIN_JSON, "utf8") : "";
mustContain(pjson, '"id": "dsh-infinite-gen-3"', "plugin.json: 插件 id（二代市场元数据移植）");
mustContain(pjson, '"version": "0.5.0"', "plugin.json: 版本 0.5.0");
check(!existsSync(join(ROOT, "prompts", "infinite-gen-2.md")), "二代提示词已并入 infinite-gen-3.md（存档已删除）");
mustContain(readFileSync(join(ROOT, "README.md"), "utf8"), "dsh://plugin/install", "README: dsh:// 一键安装协议");

// ---- 7. 汇总 ----
const json = process.argv.includes("--json");
if (json) {
  console.log(JSON.stringify({ pass: passes.length, fail: failures.length, failures }, null, 2));
} else {
  for (const p of passes) console.log(`  ✅ ${p}`);
  for (const f of failures) console.log(`  ❌ ${f}`);
  console.log(`\n结果: ${passes.length} 通过, ${failures.length} 失败`);
}
process.exit(failures.length === 0 ? 0 : 1);
